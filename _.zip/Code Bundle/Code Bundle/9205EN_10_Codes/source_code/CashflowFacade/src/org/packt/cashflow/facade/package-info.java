@javax.xml.bind.annotation.XmlSchema(namespace =
                                     "http://xmlns.oracle.com/BPELFacade/Banking_BPEL/Derivative_Cashflow",
                                     elementFormDefault =
                                     javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.packt.cashflow.facade;

