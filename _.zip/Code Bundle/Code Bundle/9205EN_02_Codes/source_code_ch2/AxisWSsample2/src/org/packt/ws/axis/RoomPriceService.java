package org.packt.ws.axis;

public class RoomPriceService {
	private RoomPrice price;

	public RoomPrice getPrice() {
		return price;
	}

	public void setPrice(RoomPrice price) {
		this.price = price;
	}
}
