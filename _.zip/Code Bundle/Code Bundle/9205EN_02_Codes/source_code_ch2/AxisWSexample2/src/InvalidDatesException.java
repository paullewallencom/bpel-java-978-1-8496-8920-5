
public class InvalidDatesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3320589454046438069L;

}
