@javax.xml.bind.annotation.XmlSchema(namespace = "http://org.packt.ws.jaxws.async/elts", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.packt.ws.jaxws.async;
