Read the sample_Instructions.pdf in the docs/ folder for a full description
of this sample.