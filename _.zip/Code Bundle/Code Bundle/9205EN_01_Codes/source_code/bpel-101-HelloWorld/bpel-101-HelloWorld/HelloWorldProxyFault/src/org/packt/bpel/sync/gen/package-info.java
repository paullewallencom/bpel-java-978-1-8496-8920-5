@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/bpel_101_HelloWorld_jws/bpel_101_HelloWorld/HelloWorldProcess", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.packt.bpel.sync.gen;
