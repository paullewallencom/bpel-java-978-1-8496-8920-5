package org.packt.user.defined;

public class ValueWithUnit {
   
    public static String formatValueWithUnit(String value, String unit) {
        return value + " " + unit;
    }
   
}
